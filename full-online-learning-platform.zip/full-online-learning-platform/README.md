
# SkillSphere Online Learning Platform

## FRONTEND
cd client
npm install
npm start

## BACKEND
cd server
npm install
npm start

## DATABASE
MongoDB Compass:
mongodb://127.0.0.1:27017
