
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const app = express();

app.use(cors());
app.use(express.json());

mongoose.connect(process.env.MONGO_URI)
.then(() => console.log('MongoDB Connected'))
.catch(err => console.log(err));

app.get('/', (req, res) => {
    res.send('SkillSphere Backend Running');
});

app.get('/courses', (req, res) => {
    res.json([
        {
            title: 'MERN Stack Development',
            instructor: 'Anlee Preethi',
            price: 4999
        },
        {
            title: 'React Masterclass',
            instructor: 'Mahesh',
            price: 2999
        }
    ]);
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
