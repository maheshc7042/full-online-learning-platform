
import React from 'react';

function App() {
  return (
    <div style={{fontFamily:'Arial',padding:'20px'}}>
      <h1>SkillSphere Online Learning Platform</h1>
      <h2>Features Included</h2>
      <ul>
        <li>Student Registration & Login</li>
        <li>Course Upload</li>
        <li>Video Lessons</li>
        <li>Admin Dashboard</li>
        <li>Student Dashboard</li>
        <li>Instructor Dashboard</li>
      </ul>

      <h2>Available Courses</h2>

      <div style={{border:'1px solid gray',padding:'15px',marginBottom:'15px'}}>
        <h3>MERN Stack Development</h3>
        <p>Learn MongoDB, Express, React and Node.</p>
        <video width="500" controls>
          <source src="https://www.w3schools.com/html/mov_bbb.mp4" type="video/mp4" />
        </video>
      </div>

      <div style={{border:'1px solid gray',padding:'15px'}}>
        <h3>React Masterclass</h3>
        <p>Complete frontend development course.</p>
        <video width="500" controls>
          <source src="https://www.w3schools.com/html/movie.mp4" type="video/mp4" />
        </video>
      </div>
    </div>
  );
}

export default App;
